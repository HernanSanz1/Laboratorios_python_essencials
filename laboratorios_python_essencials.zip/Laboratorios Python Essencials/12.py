
import time

for z in range(0,5,1):

    time.sleep(1)
    print("Mississippi",z+1)
time.sleep(2)
print("Lista o no, aquí vengo!")
