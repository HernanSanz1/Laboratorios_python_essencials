# Pedir al usuario que ingrese una palabra
user_word = input("Ingrese una palabra: ")


user_word = user_word.upper()


result_word = ""


for letter in user_word:

    if letter in 'AEIOU':
        continue

    result_word += letter

for letter in result_word:
    print(letter)
