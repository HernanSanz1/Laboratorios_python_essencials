

while True:
    palabra=str(input("Ingresa una palabra :"))
    if palabra == 'chupacabra':
        break
    print("SIGUES EN EL BUCLE")

if palabra == 'chupacabra':
    print("Has dejado el bucle con éxito.")
