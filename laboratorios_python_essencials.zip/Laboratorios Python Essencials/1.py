# ingresa un valor flotante para la variable a aquí
# ingresa un valor flotante para la variable b aquí
a=float(input("Ingrese el valor para la variable \'a\'"))
b=float(input("Ingrese el valor para la variable \'b\'"))
# mostrar el resultado de la suma aquí
print("El resultado de a + b es :",a+b)
# mostrar el resultado de la resta aquí
print("El resultado de a - b es :",a-b)
# mostrar el resultado de la multiplicación aquí
print("El resultado de a * b es :",a*b)
# mostrar el resultado de la división aquí
print("El resultado de a / b es :",a*(1/b))

print("\n¡Eso es todo, amigos!")
