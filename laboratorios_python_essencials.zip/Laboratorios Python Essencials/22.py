def liters_100km_to_miles_gallon(liters_per_100km):
    miles_per_100km = 100 * 1609.344 / 1000  # Convertir 100 km a millas
    gallons_per_100km = liters_per_100km / 3.785411784  # Convertir litros a galones
    return miles_per_100km / gallons_per_100km

def miles_gallon_to_liters_100km(miles_per_gallon):
    kilometers_per_gallon = miles_per_gallon * 1609.344 / 1000  # Convertir millas a kilómetros
    liters_per_100km = 3.785411784 / kilometers_per_gallon * 100  # Convertir galones a litros y ajustar a 100 km
    return liters_per_100km

# Prueba de las funciones
print(liters_100km_to_miles_gallon(3.9))  # 60.31143162393162
print(liters_100km_to_miles_gallon(7.5))  # 31.36194444444444
print(liters_100km_to_miles_gallon(10.0))  # 23.52145833333333

print(miles_gallon_to_liters_100km(60.3))  # 3.9007393587617467
print(miles_gallon_to_liters_100km(31.4))  # 7.490910297239916
print(miles_gallon_to_liters_100km(23.5))  # 10.009131205673757
