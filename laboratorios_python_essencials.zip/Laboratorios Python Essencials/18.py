def es_bisiesto(año):
    # Un año es bisiesto si es divisible por 4, pero no por 100, a menos que también sea divisible por 400
    if (año % 4 == 0 and año % 100 != 0) or (año % 400 == 0):
        return True
    else:
        return False

# Lista de años para probar
años_prueba = [1900, 2000, 2016, 1987, 2020]
# Lista de resultados esperados
resultados_esperados = [False, True, True, False, True]

# Verificación de los resultados
for i in range(len(años_prueba)):
    año = años_prueba[i]
    resultado = es_bisiesto(año)
    esperado = resultados_esperados[i]
    print(f"Año {año}: {resultado}, esperado: {esperado}")
    if resultado != esperado:
        print(f"Error: el resultado para el año {año} no es correcto.")

# Prueba final
for año, esperado in zip(años_prueba, resultados_esperados):
    assert es_bisiesto(año) == esperado, f"Error en el año {año}"
print("Todos los resultados son correctos.")
