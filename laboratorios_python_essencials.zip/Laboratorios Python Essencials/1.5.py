# Valores de ejemplo
miles = 10.5
kilometers = 16.9

# 1 milla equivale aproximadamente a 1.61 kilómetros
# 1 kilómetro equivale aproximadamente a 1/1.61 millas

# Convertir millas a kilómetros
miles_to_kilometers = miles * 1.61

# Convertir kilómetros a millas
kilometers_to_miles = kilometers / 1.61

# Imprimir resultados
print(miles, "millas son", round(miles_to_kilometers, 2), "kilómetros")
print(kilometers, "kilómetros son", round(kilometers_to_miles, 2), "millas")
