print("Fundamentos", "Programación", "en", sep="***", end="...")
print("Python")
