# Crear variables y asignar valores
john = 3
mary = 5
adam = 6

# Imprimir las variables en una línea separadas por comas
print(john, mary, adam, sep=", ")

# Crear una nueva variable y almacenar la suma de las tres variables anteriores
total_apples = john + mary + adam

# Imprimir el valor de total_apples
print(total_apples)

# Experimentar con el código
# Crear nuevas variables y realizar operaciones aritméticas
oranges = 4
bananas = 7
total_fruits = total_apples + oranges + bananas

# Imprimir los resultados de las nuevas operaciones
print("Número total de frutas:", total_fruits)
print("Diferencia entre total de frutas y manzanas:", total_fruits - total_apples)
print("Multiplicación de manzanas y naranjas:", john * oranges)
print("División de frutas totales por plátanos:", total_fruits / bananas)
print("División entera de frutas totales por plátanos:", total_fruits // bananas)
