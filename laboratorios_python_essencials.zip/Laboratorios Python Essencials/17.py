# Lista original con números, algunos repetidos
numeros = [1, 2, 2, 3, 4, 4, 5, 1, 6, 7, 8, 6, 9]

# Crear una nueva lista para almacenar números únicos
numeros_unicos = []

# Bucle para recorrer la lista original
for numero in numeros:
    # Si el número no está en la lista de números únicos, añadirlo
    if numero not in numeros_unicos:
        numeros_unicos.append(numero)

# Imprimir la lista original y la lista sin repeticiones
print("Lista original:", numeros)
print("Lista sin repeticiones:", numeros_unicos)
