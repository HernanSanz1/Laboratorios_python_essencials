x = float(input("Ingresa el valor para x: "))

# Escribe tu código aquí.
y= 1/(x+(1/(x+(1/(x+(1/x))))))
print("y =", y)
