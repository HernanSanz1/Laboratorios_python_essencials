def es_bisiesto(año):
    if (año % 4 == 0 and año % 100 != 0) or (año % 400 == 0):
        return True
    else:
        return False

def dias_del_mes(año, mes):
    # Verificar entradas inválidas
    if mes < 1 or mes > 12 or año < 1:
        return None
    
    # Lista de días en cada mes
    dias_por_mes = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    
    # Ajustar para febrero en un año bisiesto
    if mes == 2 and es_bisiesto(año):
        return 29
    
    return dias_por_mes[mes - 1]

# Código de prueba
años_prueba = [1900, 2000, 2016, 1987, 2020, 2021]
meses_prueba = [2, 2, 2, 2, 2, 11]
resultados_esperados = [28, 29, 29, 28, 29, 30]

for i in range(len(años_prueba)):
    año = años_prueba[i]
    mes = meses_prueba[i]
    resultado = dias_del_mes(año, mes)
    esperado = resultados_esperados[i]
    print(f"Año {año}, Mes {mes}: {resultado}, esperado: {esperado}")
    if resultado != esperado:
        print(f"Error: el resultado para el año {año} y el mes {mes} no es correcto.")

# Prueba final
for año, mes, esperado in zip(años_prueba, meses_prueba, resultados_esperados):
    assert dias_del_mes(año, mes) == esperado, f"Error en el año {año}, mes {mes}"
print("Todos los resultados son correctos.")
