# Paso 1: crea una lista vacía llamada beatles
beatles = []

# Paso 2: emplea el método append() para agregar los siguientes miembros de la banda a la lista: John Lennon, Paul McCartney y George Harrison
beatles.append("John Lennon")
beatles.append("Paul McCartney")
beatles.append("George Harrison")

# Imprimir la lista después de los primeros tres miembros
print("Después del paso 2:", beatles)

# Paso 3: emplea el bucle for y el append() para pedirle al usuario que agregue los siguientes miembros de la banda a la lista: Stu Sutcliffe, y Pete Best
for miembro in ["Stu Sutcliffe", "Pete Best"]:
    nuevo_miembro = input(f"Agrega a {miembro}: ")
    beatles.append(nuevo_miembro)

# Imprimir la lista después de agregar Stu Sutcliffe y Pete Best
print("Después del paso 3:", beatles)

# Paso 4: usa la instrucción del para eliminar a Stu Sutcliffe y Pete Best de la lista
del beatles[-2]
del beatles[-1]

# Imprimir la lista después de eliminar a Stu Sutcliffe y Pete Best
print("Después del paso 4:", beatles)

# Paso 5: usa el método insert() para agregar a Ringo Starr al principio de la lista
beatles.insert(0, "Ringo Starr")

# Imprimir la lista final después de agregar a Ringo Starr
print("Después del paso 5:", beatles)
