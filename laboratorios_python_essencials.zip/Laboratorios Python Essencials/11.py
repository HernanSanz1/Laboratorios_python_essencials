secret_number = 777

print(
"""
+================================+
| ¡Bienvenido a mi juego, muggle!|
| Introduce un número entero     |
| y adivina qué número he        |
| elegido para ti.               |
|¿Cuál es el número secreto?     |
+================================+
""")
numero=int(input())

while numero!=secret_number :
    print("¡Ja, ja! ¡Estás atrapado en mi bucle!")
    numero=int(input("¿Cuál es el número secreto? "))
    
if numero==secret_number :
    print("Bien hecho, muggle! Eres libre ahora.")
