print("\"Estoy\"\n\"aprendiendo\"\n\"Python\"")
