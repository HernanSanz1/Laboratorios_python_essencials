import random

# Función para mostrar el tablero
def mostrar_tablero(board):
    for row in board:
        print("+-------" * 3 + "+")
        print("|       " * 3 + "|")
        for cell in row:
            print(f"|   {cell}   ", end="")
        print("|")
        print("|       " * 3 + "|")
    print("+-------" * 3 + "+")

# Función para verificar si alguien ha ganado
def verificar_victoria(board, signo):
    for row in board:
        if all(cell == signo for cell in row):
            return True
    for col in range(3):
        if all(row[col] == signo for row in board):
            return True
    if all(board[i][i] == signo for i in range(3)) or all(board[i][2-i] == signo for i in range(3)):
        return True
    return False

# Función para verificar si hay un empate
def verificar_empate(board):
    for row in board:
        for cell in row:
            if cell not in ['X', 'O']:
                return False
    return True

# Función para realizar el movimiento de la computadora
def movimiento_computadora(board):
    while True:
        move = random.randrange(1, 10)
        for row in range(3):
            for col in range(3):
                if board[row][col] == move:
                    board[row][col] = 'X'
                    return

# Función principal
def main():
    # Inicializar el tablero
    board = [[1, 2, 3], [4, 'X', 6], [7, 8, 9]]
    
    while True:
        mostrar_tablero(board)
        
        # Movimiento del usuario
        while True:
            try:
                move = int(input("Ingresa tu movimiento (1-9): "))
                if move < 1 or move > 9:
                    raise ValueError
                for row in range(3):
                    for col in range(3):
                        if board[row][col] == move:
                            board[row][col] = 'O'
                            break
                    else:
                        continue
                    break
                else:
                    print("Cuadro ocupado. Intenta de nuevo.")
                    continue
                break
            except ValueError:
                print("Entrada inválida. Ingresa un número del 1 al 9.")
        
        if verificar_victoria(board, 'O'):
            mostrar_tablero(board)
            print("¡Has Ganado!")
            break
        if verificar_empate(board):
            mostrar_tablero(board)
            print("¡Es un empate!")
            break
        
        # Movimiento de la computadora
        movimiento_computadora(board)
        
        if verificar_victoria(board, 'X'):
            mostrar_tablero(board)
            print("¡La computadora ha ganado!")
            break
        if verificar_empate(board):
            mostrar_tablero(board)
            print("¡Es un empate!")
            break

if __name__ == "__main__":
    main()
