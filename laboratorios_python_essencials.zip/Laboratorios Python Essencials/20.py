def es_bisiesto(año):
    if (año % 4 == 0 and año % 100 != 0) or (año % 400 == 0):
        return True
    else:
        return False

def dias_del_mes(año, mes):
    if mes < 1 or mes > 12 or año < 1:
        return None
    
    dias_por_mes = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    
    if mes == 2 and es_bisiesto(año):
        return 29
    
    return dias_por_mes[mes - 1]

def dia_del_año(año, mes, dia):
    if año < 1 or mes < 1 or mes > 12 or dia < 1:
        return None
    
    dias_en_mes = dias_del_mes(año, mes)
    if dias_en_mes is None or dia > dias_en_mes:
        return None
    
    dias_totales = 0
    for m in range(1, mes):
        dias_totales += dias_del_mes(año, m)
    
    return dias_totales + dia

# Código de prueba
años_prueba = [2020, 2020, 2019, 2000, 2001, 2021]
meses_prueba = [1, 2, 3, 2, 12, 11]
días_prueba = [1, 29, 31, 29, 31, 30]
resultados_esperados = [1, 60, 90, 60, 365, 334]

for i in range(len(años_prueba)):
    año = años_prueba[i]
    mes = meses_prueba[i]
    dia = días_prueba[i]
    resultado = dia_del_año(año, mes, dia)
    esperado = resultados_esperados[i]
    print(f"Año {año}, Mes {mes}, Día {dia}: {resultado}, esperado: {esperado}")
    if resultado != esperado:
        print(f"Error: el resultado para el año {año}, mes {mes}, día {dia} no es correcto.")

# Prueba final
for año, mes, dia, esperado in zip(años_prueba, meses_prueba, días_prueba, resultados_esperados):
    assert dia_del_año(año, mes, dia) == esperado, f"Error en el año {año}, mes {mes}, día {dia}"
print("Todos los resultados son correctos.")
